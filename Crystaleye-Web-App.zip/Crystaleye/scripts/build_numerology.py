#!/usr/bin/env python3
"""Build topic/result routes from completed-PDF extracts and explicit placeholders."""
import json
from html import escape as e
from site_images import image_tag, brand_mark
from pathlib import Path
from library_components import pdf_library
from site_metadata import write_html
from site_components import ROOT, merchandise, mobile_toolbar, quick_numerology_calculator
CONFIG=json.loads((ROOT/'data/numerology-topics.json').read_text())
READINGS=json.loads((ROOT/'data/numerology-profiles.json').read_text())['topics']
TOPICS=CONFIG['topics'];STANDARD=CONFIG['standard_routes'];OUT=ROOT/'numerology'

def topic_image(t,prefix,cls='',eager=False):
    return image_tag('numerology.topic.'+t['slug'],prefix,t['name']+' cyberpunk illustration',cls,eager)

def result_art(t,n):
    if n in STANDARD:return image_tag('numerology.number.'+str(n),'../../../','Number '+str(n)+' in neon artwork','',True)
    return topic_image(t,'../../../',eager=True)


def page(title,description,body,depth=1,interactive=False,indexable=True):
    p='../'*depth;home=p+'numerology/index.html'
    return f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#080b19"><meta name="description" content="{e(description)}">{'' if indexable else '<meta name="robots" content="noindex,follow">'}<title>{e(title)} | Crystaleye</title><link rel="icon" href="{p}assets/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="{p}assets/site.css"><link rel="stylesheet" href="{p}numerology/numerology.css"><link rel="stylesheet" href="{p}assets/merchandise.css"><link rel="stylesheet" href="{p}assets/cyberpunk.css"><link rel="stylesheet" href="{p}assets/mobile-toolbar.css?v=3"><script src="{p}assets/site.js" defer></script>{'<script type="module" src="numerology.js"></script>' if interactive else ''}</head><body><a class="skip-link" href="#main">Skip to content</a><header class="site-header wrap"><a class="brand" href="{p}index.html" aria-label="Crystaleye home">{brand_mark(p)}<span>crystaleye<span class="brand-dot">.</span></span></a><button class="menu-toggle" type="button" aria-expanded="false" aria-controls="site-nav"><span>Menu</span><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3 6h14M3 14h14"/></svg></button><nav id="site-nav" aria-label="Main navigation"><a href="{home}">Numerology</a><a href="{home}#numbers">The 21 numbers</a><a href="{p}astrology/index.html">Astrology</a></nav><a class="header-cta" href="{home}#calculator">Start with your three →</a></header><main id="main">{body}{merchandise(p)}</main><footer class="site-footer wrap num-footer"><a class="brand" href="{p}index.html">crystaleye<span class="brand-dot">.</span></a><nav aria-label="Footer"><a href="{home}">Numerology home</a><a href="{p}numerology-calculator/index.html">Full calculator</a><a href="{p}numerology/report.html">The full report</a><a href="{p}tarot/index.html">Tarot</a><a href="{p}merchandise/index.html">Books &amp; decks</a></nav><p>Numerology is a symbolic tradition for reflection, not a scientifically validated assessment or prediction method. Different schools use different calculation conventions; a number does not determine your worth or future.</p></footer>{mobile_toolbar(p,'Numerology')}</body></html>'''

def report_offer(prefix=''):
    r=CONFIG['report']
    return f'''<section class="num-report"><div><p class="eyebrow">A fuller picture, at your pace</p><h2>Your numbers.<br>Your <em>whole story.</em></h2><p>The planned Full Numerology report brings your 21 chart positions together in one expanded reading. The remaining guide content and ordering details are still being prepared.</p></div><div><h3>{r['name']}</h3><p class="report-price">${r['price']} <span>CAD · one-time purchase</span></p><p class="num-status">Coming soon · ordering is not open</p><a class="button button-gold" href="{prefix}report.html">Explore the full report →</a><p class="fine-print">No payment, email address, or personal details are collected here.</p></div></section>'''

def badge(t):return f"{len(READINGS[t['slug']]['profiles'])} profiles ready" if t['slug'] in READINGS else 'Profiles coming soon'

def number_label(t,n):
    if n in [11,22,33] and t['slug'] not in ['birthday','karmic-lessons','hidden-passion','balance'] and 'challenge' not in t['slug']:return f'{n}/{ {11:2,22:4,33:6}[n]}'
    return str(n)

def grid_numbers(t,extra=False):
    values=([0] if t['group']=='Challenges' else [])+STANDARD
    if t['slug']=='birthday':values+=[n for n in range(1,32) if n not in values]
    if extra:values=[n for n in values if n not in STANDARD]
    elif t['slug']=='birthday':values=STANDARD
    tiles=[]
    profiles=READINGS.get(t['slug'],{}).get('profiles',{})
    for n in values:
        profile=profiles.get(str(n));alias=t['slug']=='balance' and n in [11,22,33]
        state='ready' if profile else ('reference' if alias else ('coming-soon' if n in t['valid_results'] else 'convention'))
        status={'ready':'Profile available','reference':'Guide mapping','coming-soon':'Coming soon','convention':'Range note'}[state]
        title=profile['subtitle'] if profile else ('Read the guide mapping' if alias else ('Interpretation in preparation' if state=='coming-soon' else 'Check this position’s range'))
        action='Read your profile →' if profile else ('View mapping →' if alias else 'View preview →' if state=='coming-soon' else 'Check convention →')
        art=image_tag('numerology.number.'+str(n),'../../','','number-tile-image') if n in STANDARD else ''
        tiles.append(f'<a class="number-tile" data-status="{state}" href="number-{n}/">{art}<span>{number_label(t,n)}</span><small class="availability-badge">{status}</small><strong class="number-profile-title">{e(title)}</strong><small class="number-profile-action">{action}</small></a>')
    return '<div class="number-grid">'+''.join(tiles)+'</div>'

def hub():
    groups=list(dict.fromkeys(t['group'] for t in TOPICS))
    cards=''.join(f'''<article class="topic-card" data-group="{e(t['group'])}" data-search="{e(t['name'].lower())}">{topic_image(t,"../","topic-card-image")}<p class="eyebrow">{t['group']}</p><h3><a href="{t['slug']}/">{e(t['name'])} →</a></h3><p>{e(t['overview'])}</p><span class="topic-state {'is-ready' if t['slug'] in READINGS else ''}">{badge(t)}</span></article>''' for t in TOPICS)
    body=f'''<section class="wrap num-hero"><div><p class="eyebrow"><span class="tiny-star" aria-hidden="true">✧</span> The numerology wing</p><h1>Your name.<br>Your birthday.<br><em>A different angle.</em></h1><p class="section-copy">Start with three numbers. Get curious about the patterns. Explore the stories attached to them, without handing over the authorship of your own life.</p><div class="hero-actions"><a class="button button-gold" href="#calculator">Find your three numbers →</a><a class="text-link" href="#what-is-numerology">New to numerology? Start here →</a></div></div><div class="numerology-hero-art">{''.join(f'<figure>{topic_image(t,"../",eager=True)}<figcaption>{e(t["name"])}</figcaption></figure>' for t in [next(t for t in TOPICS if t['slug']==key) for key in ['personality','life-path','destiny']])}</div></section>
<section class="wrap num-section" id="what-is-numerology"><div class="num-topline"><p class="eyebrow">01 / A little context</p><span>Numbers as a language for reflection</span></div><h2>What is <em>numerology?</em></h2><div class="num-explainer"><article><h3>A symbolic reading of names and dates.</h3><p>Numerology assigns meanings to numbers and uses conventions to derive them from information such as a name or birth date. In the Western name-based system used here, letters repeat through values 1–9. A date is broken into components and reduced according to the chart position.</p><p>Different numbers ask different questions: Personality concerns outward impression, Life Path concerns development, and Destiny or Expression concerns contribution. These are interpretive themes, rather than scientific measurements of who you are.</p></article><article><h3>How old is it?</h3><p>Number symbolism has roots stretching back thousands of years. Greek Pythagorean traditions developed around the sixth and fifth centuries BCE—roughly 2,500 years ago—and linked numbers with patterns, harmony, and ideas about the world.</p><p>Today’s name-and-birth-date systems developed through later traditions and vary between schools. There is no single founding date for every practice called numerology. The age of number symbolism does not establish that a present-day reading can predict events.</p><a class="text-link" href="https://plato.stanford.edu/entries/pythagoras/" target="_blank" rel="noopener noreferrer">Historical context: Pythagoras →</a></article></div></section>
{quick_numerology_calculator("../")}
<section class="wrap num-section" id="numbers"><div class="num-topline"><p class="eyebrow">03 / The chart library</p><span>21 positions. Different questions.</span></div><h2>Find the number.<br><em>Follow the thread.</em></h2><p class="section-copy">Each topic explains what it represents and how it is calculated. Seven completed guides supply the profiles available now; the other result pages are clearly marked as coming soon.</p><div class="topic-controls" id="topic-controls" hidden><label class="topic-search">Find a topic<input id="topic-search" type="search" placeholder="Try “personality” or “third”"></label><div class="topic-filters" aria-label="Filter number topics">{''.join(f'<button type="button" data-group-filter="{e(g)}" aria-pressed="{str(g=="All").lower()}">{g}</button>' for g in ['All']+groups)}</div></div><p class="fine-print" id="topic-count" aria-live="polite">21 topics</p><div class="topic-grid">{cards}</div><p class="topic-empty notice" id="topic-empty" hidden>No topics match. Try another search or choose All.</p></section>{pdf_library("../")}<div class="wrap num-section">{report_offer()}</div>'''
    return page('Numerology — Your first three numbers & the 21-number library','What numerology means, its historical roots, a simple Personality/Life Path/Destiny calculator, 21 topic libraries, and the upcoming $19.99 CAD report.',body,interactive=True)

def topic_page(t):
    slug=t['slug'];guide=READINGS.get(slug);source=f'<a class="button button-outline" href="../../{guide["pdf"]}">Read the completed PDF guide →</a>' if guide else '<p class="num-status">Detailed profiles coming soon · guide not yet complete</p>'
    extra=''
    if slug=='birthday':extra='<h3 class="extra-heading">More calendar-day values</h3><p class="section-copy">Birthday keeps the unreduced day, so 10 and 12–31 also need their own routes. The 11 and 22 pages appear in the main grid above.</p>'+grid_numbers(t,True)
    body=f'''<div class="wrap num-breadcrumb"><a href="../index.html">Numerology</a><span>/</span><span>{e(t['name'])}</span></div><section class="wrap topic-hero"><div><p class="eyebrow">{t['group']} / {badge(t)}</p><h1>{e(t['name'])}<em> number.</em></h1><p class="section-copy">{e(t['overview'])}</p><div class="hero-actions"><a class="button button-gold" href="#results">Find your result →</a><a class="text-link" href="#calculation">How it is calculated →</a></div></div><figure class="topic-art">{topic_image(t,"../../",eager=True)}</figure></section><section class="wrap method-layout" id="calculation"><div><p class="eyebrow">What this number tells you</p><h2>A different <em>lens.</em></h2><p>{e(t['overview'])}</p>{source}</div><div class="method-box"><p class="eyebrow">How it is calculated</p><ol>{''.join('<li>'+e(s)+'</li>' for s in t['steps'])}</ol><details open><summary>Conventions worth knowing</summary><p>{e(t['convention_note'])}</p></details></div></section><section class="wrap num-section" id="results"><div class="num-topline"><p class="eyebrow">Explore this position</p><span>Read the status beneath each number</span></div><h2>Your result.<br><em>Its own context.</em></h2><p class="section-copy">The twelve requested number routes appear below. A convention note identifies values this position does not produce. Unfinished interpretations remain placeholders, rather than general meanings borrowed from a different chart position.</p>{grid_numbers(t)}{extra}{'<p class="notice">No missing values means no selected Karmic Lessons. It is an empty set, not Lesson 0 or proof that development is complete.</p>' if slug=='karmic-lessons' else ''}</section><div class="wrap num-section">{report_offer('../')}</div>'''
    return page(t['name']+' — Meaning, calculation & result library',t['overview'],body,2)

def reserved_note(t,n):
    slug=t['slug']
    if slug=='birthday':return 'There is no thirty-third calendar day. This project keeps Birthday as the original day, 1–31, so Birthday 33 is not a possible result.'
    if slug in ['karmic-lessons','hidden-passion']:return f'{t["name"]} works with letter-value categories 1–9. It can return several values, but they are not added together or renamed as master 11, 22, or 33.'
    if t['group']=='Challenges':return 'This is a reserved convention page, not a published master Challenge profile. Standard fully reduced Challenge methods use 0–9. Crystaleye’s custom master-preserving, zero-clamped subtraction can produce different unreduced outputs; its formula is explained on the topic page. A researched interpretation for this value is not available.'
    if slug=='first-life-cycle':return f'The First Life Cycle uses the birth month. Under this app’s reduction rule, months can yield 1–9 or 11, so {n} is not produced by this position.'
    if slug=='second-life-cycle':return f'The Second Life Cycle uses a calendar day from 1–31. With the stated reduction rule, that can yield 1–9, 11, or 22; it cannot yield {n}.'
    return f'Within the current 1800–2026 birth-year range, this year-based position does not produce {n} under the stated reduction rule. This route preserves the requested library structure and explains the range.'

def result_page(t,n):
    slug=t['slug'];guide=READINGS.get(slug);profile=guide and guide['profiles'].get(str(n));alias=slug=='balance' and n in [11,22,33];valid=n in t['valid_results'];label=number_label(t,n)
    if profile:
        status='From the completed guide';title=profile['subtitle'];paras=''.join(f'<section class="reading-part"><h2>{heading}</h2><p>{e(text)}</p></section>' for heading,text in zip(['The central theme','A possible tension','A constructive direction'],profile['paragraphs']))
        sources=''.join(f'<li><a href="{e(s["url"])}" target="_blank" rel="noopener noreferrer">{e(s["title"])}</a>{"<p>"+e(s["role"])+"</p>" if s.get("role") else ""}</li>' for s in profile['sources'])
        content=f'''<div class="profile-prose">{paras}<details class="profile-evidence"><summary>Guide provenance and interpretation notes</summary><p>{e(profile['evidence_note'])}</p><p>This reading is copied from the completed {e(t['name'])} guide, page {profile['pdf_page']}. The final paragraph is constructive editorial synthesis. It is not a new forecast or a claim about your abilities or future.</p><a class="text-link" href="../../../{guide['pdf']}#page={profile['pdf_page']}">Open this page in the PDF →</a>{'<ul>'+sources+'</ul>' if sources else '<p>The PDF bibliography records the source references used in this profile.</p>'}</details></div>'''
    elif alias:
        root={11:2,22:4,33:6}[n];status='Guide cross-reference';title=f'For app Balance {n}, read guide {root}.'
        content=f'''<section class="placeholder-panel"><p class="eyebrow">A calculation difference, explained</p><h2>One position.<br><em>Two reduction conventions.</em></h2><p>The full calculator keeps a Balance total of {n}. The completed guide reduces Balance fully, so {n} becomes {root}. It does not provide a separate Balance {n} personality or master profile.</p><p>Use the completed Balance {root} reading for the guide’s selected method. Your original app result has not been changed.</p><a class="button button-gold" href="../number-{root}/">Read Balance {root} →</a></section>'''
    elif valid:
        status='Profile coming soon';title='This specific reading is still to come.'
        content=f'''<section class="placeholder-panel"><p class="eyebrow">A clearly marked placeholder</p><h2>A place for the<br><em>next chapter.</em></h2><p>A completed {e(t['name'])} {n} interpretation has not been published in this series yet. This page reserves its route; it does not substitute a general number-{n} meaning or material from an unfinished research draft.</p><p>{e(t['overview'])}</p><a class="button button-outline" href="../#calculation">Understand this position’s calculation →</a></section>'''
    else:
        status='Range & convention note';title='Check the position before the meaning.'
        content=f'''<section class="placeholder-panel"><p class="eyebrow">A reserved route</p><h2>The same numeral<br><em>has different rules.</em></h2><p>{e(reserved_note(t,n))}</p><a class="button button-outline" href="../#results">Return to the valid-result notes →</a></section>'''
    body=f'''<div class="wrap num-breadcrumb"><a href="../../index.html">Numerology</a><span>/</span><a href="../">{e(t['name'])}</a><span>/</span><span>{n}</span></div><section class="wrap result-hero"><div><p class="eyebrow">{e(t['name'])} / {status}</p><h1>{e(t['name'])}<br><em>{label}.</em></h1><p class="result-subtitle">{e(title)}</p></div><figure class="result-art">{result_art(t,n)}</figure></section><div class="wrap result-layout"><aside><p class="eyebrow">Keep the context</p><p>{e(t['overview'])}</p><a href="../#calculation">How this number is calculated →</a><a href="../#results">All {e(t['name'])} results →</a><a href="../../index.html#calculator">Try the quick calculator →</a>{'<a href="../../../'+guide['pdf']+'">The complete PDF guide →</a>' if guide else '<span class="fine-print">Topic guide in preparation</span>'}</aside>{content}</div><section class="wrap result-next"><p class="eyebrow">Keep exploring this position</p><nav aria-label="Other {e(t['name'])} results">{''.join(f'<a href="../number-{x}/" {"aria-current=\"page\"" if x==n else ""}>{x}</a>' for x in (([0] if t['group']=='Challenges' else [])+STANDARD))}</nav></section>'''
    return page(f'{t["name"]} {label} — {title}',f'{t["name"]} {n}: {status.lower()}. '+t['overview'],body,3,indexable=bool(profile))

def report():
    r=CONFIG['report'];body=f'''<section class="wrap report-hero"><p class="eyebrow">Your full chart, thoughtfully explained</p><h1>More than<br><em>three numbers.</em></h1><p class="section-copy">The planned {r['name']} brings together the 21 positions in your chart, giving each number its own context and explaining how the positions differ.</p><p class="report-price">${r['price']} <span>CAD · one-time purchase</span></p><p class="num-status">Coming soon · no orders or payments are being accepted</p><a class="button button-gold" href="index.html#calculator">Start with your free three numbers →</a></section><section class="wrap report-details"><div><p class="eyebrow">The planned reading</p><h2>Your chart.<br><em>In context.</em></h2><p>Personality, Soul’s Desire, Life Path, and Destiny; the current-name Minor numbers; Balance, Karmic Lessons, Hidden Passion, and Birthday; three Life Cycles, four Pinnacles, and four Challenges. Set-valued results stay as sets, and calculation conventions will be identified.</p><p>The result library is being built from the completed research guides. Remaining profiles are still placeholders, so a finished paid report is not being offered for immediate delivery.</p></div><div class="method-box"><h3>Before ordering opens</h3><p>Delivery format, final contents, checkout terms, and secure payment will be provided before sales begin. This page collects no name, birth date, email address, or payment information.</p><p>The full calculator remains free to use if you want to see all 21 values now. The planned paid report adds an expanded reading, rather than another set of calculations.</p><a class="text-link" href="../numerology-calculator/index.html">Open the full calculator →</a><a class="text-link" href="index.html#numbers">Explore the available guides →</a></div></section>'''
    return page(r['name']+' — $'+r['price']+' CAD, coming soon','Explore the planned one-time $19.99 CAD full numerology report for all 21 chart positions. Ordering is not yet open.',body)

def main():
    OUT.mkdir(exist_ok=True);write_html(OUT/'index.html',hub());write_html(OUT/'report.html',report());count=0
    for t in TOPICS:
        folder=OUT/t['slug'];folder.mkdir(exist_ok=True);write_html(folder/'index.html',topic_page(t))
        values=([0] if t['group']=='Challenges' else [])+STANDARD
        if t['slug']=='birthday':values+= [n for n in range(1,32) if n not in values]
        for n in values:
            dest=folder/f'number-{n}';dest.mkdir(exist_ok=True);write_html(dest/'index.html',result_page(t,n));count+=1
    summaries={}
    for slug in ['personality','life-path','destiny']:
        summaries[slug]={number:{'title':p['subtitle'],'summary':p['paragraphs'][0].split('. ')[0].rstrip('.')+'.'} for number,p in READINGS[slug]['profiles'].items()}
    (OUT/'result-summaries.mjs').write_text('// Generated from completed guide profiles by build_numerology.py.\nexport default '+json.dumps(summaries,ensure_ascii=False,indent=2)+';\n')
    print(f'Built numerology hub, report offer, {len(TOPICS)} topic pages, and {count} result routes.')

if __name__=='__main__':main()
