# Crystaleye Web App

## Run locally

1. Extract the entire ZIP.
2. Open a terminal in the extracted `Crystaleye` folder.
3. Run `python3 -m http.server 8000 --bind 127.0.0.1` (on Windows, use `py -3` in place of `python3`).
4. Open http://127.0.0.1:8000/ in your browser.

Use a local server so JavaScript modules and calculators load correctly. The site is prebuilt. The homepage, tarot, astrology, numerology, shop catalog, and PDF guides are included.

## Host or configure

For static hosting, publish the root index.html and the account, assets, astrology, merchandise, numerology, numerology-calculator, output, psychic-readings, shop, and tarot folders, together with the root PDFs. Keep this directory structure. The other folders are for setup, rebuilding, and testing. The main README documents the project.

- **Supabase accounts.** The site includes its existing public connection settings. Account sign-in requires internet access and an allowed redirect for the URL you use. For the local command above, the callback is `http://127.0.0.1:8000/account/`. See `docs/CUSTOMER_ACCOUNTS.md` and the included Supabase migration.
- **Stripe checkout.** Ordering is disabled in the current catalog. See `docs/STRIPE_SETUP.md` for how the owner can configure hosted Payment Links. Paid subscriptions require additional fulfillment setup.
- **Psychic reading bookings.** Booking submissions depend on the external Worker, D1 database, and Turnstile. See `booking-service/README.md` for setup.

The bundle contains no private API keys, database exports, or installed dependencies.
